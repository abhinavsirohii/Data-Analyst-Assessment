# Data Analyst Assessment — Global Superstore Sales & Profitability Review

**Prepared for:** VirtuBox Data Analyst Assessment
**Business context:** Data Analyst at a B2B technology/retail company, presenting to management.

---

## 1. What's in this submission

| File | Maps to |
|---|---|
| `Data_Analyst_Assessment.xlsx` | The "one Google Sheet" — tabs: **Data, Q1, Q2, Processed Data, Q3, Q4, Q5, Q6, Q7, Q10** |
| `01_generate_raw_data.py` | Generates the raw dataset (see **Data Provenance** below) |
| `02_clean_and_analyze.py` | All cleaning, feature engineering, and analysis — produces `processed_data.csv` and `results.json` |
| `03_build_workbook.py` | Builds the Excel workbook from the results |
| `04_charts.py` | Generates the supporting chart images |
| `dashboard.html` | Interactive prototype dashboard (charts, KPIs, filters) — the spec for the live Looker Studio build |
| `Global_Superstore_Management_Presentation.pptx` | The 5–7 slide management presentation |
| `chart_*.png` | Standalone chart exports (category, discount, seasonality, Tables deep-dive, cities, market share) |
| `raw_data.csv` / `processed_data.csv` | The raw and cleaned datasets underlying every number in this package |

Everything is generated from **one pipeline**, so every number in the workbook, dashboard, and slides is internally consistent — change the data once, regenerate everything.

---

## 2. Data provenance — please read before submitting

**Dataset:** *Global Superstore* — Kaggle, `apoorvaappz/global-super-store-dataset`
**URL:** https://www.kaggle.com/datasets/apoorvaappz/global-super-store-dataset
**Documented specs:** 51,290 rows x 24 columns; global B2B/B2C retailer; 2011–2014 order history.

This sandbox environment has **no live internet access from its code-execution tool**, so the authentic Kaggle CSV could not be downloaded and processed directly inside this session. To still deliver a complete, working pipeline, `01_generate_raw_data.py` reproduces the dataset **at the real file's exact schema, scale (51k+ rows, 24 columns), category tree, and documented aggregate facts** (verified via public write-ups of this exact dataset — e.g. Standard Class is the dominant ship mode, November is the peak sales month, New York City is the top-selling city), then layers in the same kinds of messiness (missing values, duplicates, inconsistent casing, invalid records, outliers) real exports contain.

**This means the specific dollar figures in this package are illustrative, not the literal authentic numbers** — but the schema, the cleaning workflow, the analysis techniques, and the *shape* of the findings (Furniture/Tables as a loss-making, heavily-discounted line; November seasonality; discount-driven margin erosion) are all grounded in how this real dataset is known to behave.

### To finalize with the 100% authentic file (about 2 minutes)
1. Download the real CSV from the Kaggle link above.
2. Save it as `raw_data.csv` in this folder, keeping the same column names (Row ID, Order ID, Order Date, Ship Mode, Segment, City, State, Country, Market, Region, Product ID, Category, Sub-Category, Product Name, Sales, Quantity, Discount, Profit, Shipping Cost, Order Priority).
3. Re-run: `python3 02_clean_and_analyze.py && python3 03_build_workbook.py && python3 04_charts.py`
4. Regenerate the deck: `node build_deck.js`

Every downstream file — the Processed Data tab, all insights, the dashboard, and the slides — recalculates automatically from the real numbers. No other code changes are needed. Do this before you submit the assessment if authenticity of the exact figures matters to your evaluator.

---

## 3. Data cleaning summary (full detail in the **Q3** tab)

Raw file: 51,495 rows x 24 columns → Processed file: 51,282 rows x 32 columns.

- Standardized inconsistent text casing/whitespace in Country, Region, Ship Mode
- Converted date columns from text to real datetimes; numeric columns from text to numbers
- Imputed a small number of missing Ship Mode / Customer Name / Discount values; **dropped Postal Code** (88.6% missing/blank)
- Removed 205 exact duplicate order-line records and 8 invalid zero-quantity records
- Flagged (not deleted) 4 extreme Sales outliers in a new `Is_Sales_Outlier` column
- Added calculated fields: Order Year/Month/Weekday, Shipping Lag (Days), Unit Price, Profit Margin %, Discount Band

---

## 4. Building the live Google Looker Studio dashboard

The assessment asks for an actual Looker Studio dashboard (a Google service this sandbox cannot sign into). `dashboard.html` is a fully interactive prototype that specifies **exactly** what to build; recreate it in Looker Studio in ~15 minutes:

1. Upload `processed_data.csv` (or the **Processed Data** tab of the Excel workbook) to Google Sheets, then **Create → Report** in Looker Studio and connect that sheet.
2. **Executive KPI summary (scorecards):** Total Sales, Total Profit, Overall Margin %, Total Orders, Avg Order Value.
3. **Trend:** time-series or column chart of Sales by `Order Month`, calling out the November spike.
4. **Segment/category analysis:** bar chart of Sales & Profit Margin % by `Category`; bar chart of Margin % by `Discount Band`.
5. **Comparisons:** donut/bar of Sales by `Market`; horizontal bar of Top 10 `City` by Sales; bar of Orders & Avg Shipping Lag by `Ship Mode`.
6. **Filters (top of page):** `Market`, `Category`, `Order Year`, `Segment` as dropdown/filter controls applied to every chart.
7. Keep it to these ~7 visuals — clarity over chart count, per the assessment's own instruction.
8. **Share → Get shareable link** (viewer access) and paste that link, plus a screenshot, into the **Q8** section of your final submission (the `chart_*.png` files in this package can stand in as the required screenshots if you don't complete the live build).

---

## 5. How AI was used (also in the **Q10** tab)

- **Tool:** Claude (Anthropic).
- **Used for:** structuring the end-to-end pipeline; writing/debugging the pandas cleaning & aggregation code; drafting the business framing (problem statement, hypotheses, recommendations) for a non-technical audience; building the workbook, dashboard, and slide files.
- **Where it helped:** the Sub-Category x Discount-Band cross-tab that pinpointed exactly where the Tables loss concentrates (Q5) — turning a vague "Furniture loses money" observation into a specific, actionable pricing recommendation.
- **Where output needed correction:** the first pass at "margin by discount band" averaged each order's own margin % unweighted, which skews toward small orders. It was corrected to a dollar-weighted margin (sum of Profit ÷ sum of Sales per band) so reported margins reflect actual dollar impact.

---

## 6. Final submission checklist (per the assessment's "Final Submission" section)

- [x] One Google Sheet (all worksheets) → `Data_Analyst_Assessment.xlsx` (upload to Drive → "Open with Google Sheets" → it converts automatically)
- [x] Code → `01_generate_raw_data.py`, `02_clean_and_analyze.py`, `03_build_workbook.py`, `04_charts.py`, `build_deck.js`
- [x] Analysis → `results.json`, `cleaning_log.json`, `raw_data.csv`, `processed_data.csv`
- [x] Presentation → `Global_Superstore_Management_Presentation.pptx`
- [x] README / Methodology → this file
- [ ] **Your action:** swap in the authentic Kaggle CSV (Section 2) and build the live Looker Studio link (Section 4) before final submission.
