"""
Cleans raw_data.csv -> processed_data.csv, and computes every number needed for
Q3 (cleaning log), Q4 (insights), Q5 (surprise), Q6 (data quality), Q7 (recommendations).
Outputs a single results.json consumed by the workbook/deck/dashboard builders.
"""
import pandas as pd
import numpy as np
import json

pd.set_option("display.width", 160)

raw = pd.read_csv("/home/claude/project/raw_data.csv", dtype=str)
n_raw_rows, n_raw_cols = raw.shape

df = raw.copy()
log = []  # (change, why, what_if_not)

# 1. Standardize text case issues -----------------------------------------------
before = df["Country"].nunique()
df["Country"] = df["Country"].str.strip().str.title().replace({"United States Of America": "United States"})
df["Region"] = df["Region"].str.strip()
df["Ship Mode"] = df["Ship Mode"].str.strip().str.title()
after = df["Country"].nunique()
log.append(("Standardized text casing/whitespace in Country, Region, Ship Mode",
            f"Raw exports had mixed case ('UNITED STATES' vs 'United States') and a stray "
            f"trailing space in some 'Region' values, which silently created duplicate "
            f"categories (Country categories dropped from {before} to {after} unique labels).",
            "Every groupby/pivot on Country or Region would double-count categories, "
            "understating each true group's totals and corrupting every downstream KPI."))

# 2. Fix data types --------------------------------------------------------------
df["Order Date"] = pd.to_datetime(df["Order Date"], format="%d-%m-%Y", errors="coerce")
df["Ship Date"] = pd.to_datetime(df["Ship Date"], format="%d-%m-%Y", errors="coerce")
for c in ["Sales", "Quantity", "Discount", "Profit", "Shipping Cost"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")
log.append(("Converted Order Date/Ship Date from text to datetime; Sales, Quantity, "
            "Discount, Profit, Shipping Cost from text to numeric",
            "Source columns were plain text strings. Dates need to be real datetimes to "
            "extract Year/Month/weekday and compute shipping lag; numeric fields must be "
            "true numbers to sum, average, or compare correctly.",
            "Text-typed numbers sort and aggregate lexicographically (e.g. '9' > '80'), and "
            "date math / time-trend charts are impossible on text dates."))

# 3. Handle missing values --------------------------------------------------------
n_missing_ship_mode = df["Ship Mode"].isna().sum()
df["Ship Mode"] = df["Ship Mode"].fillna(df["Ship Mode"].mode()[0])
n_missing_name = df["Customer Name"].isna().sum()
df["Customer Name"] = df["Customer Name"].fillna("Unknown Customer")
n_missing_discount = df["Discount"].isna().sum()
df["Discount"] = df["Discount"].fillna(0.0)
postal_missing_pct = round(df["Postal Code"].isna().mean() * 100 + (df["Postal Code"] == "").mean() * 100, 1)
df = df.drop(columns=["Postal Code"])  # >80% missing/blank, not usable for geographic analysis
log.append(("Imputed a small number of missing Ship Mode (mode), Customer Name "
            "('Unknown Customer'), and Discount (0) values; dropped the Postal Code column entirely",
            f"Ship Mode/Customer Name/Discount had a small number of NaNs (<0.5% each) so simple, "
            f"defensible fills preserve those rows. Postal Code was blank for ~{postal_missing_pct}% "
            f"of records (mostly non-US orders, plus half of US orders) — too sparse to support "
            f"any reliable ZIP-level analysis.",
            "Leaving the NaNs would silently drop those rows from every aggregation function "
            "(sum/mean ignore NaN inconsistently across tools); keeping an 80%+ empty column "
            "risks a reviewer trusting a 'ZIP code' breakdown built on a fifth of the data."))

# 4. Remove duplicates -------------------------------------------------------------
n_before = len(df)
dup_mask = df.duplicated(subset=[c for c in df.columns if c != "Row ID"], keep="first")
n_dupes = int(dup_mask.sum())
df = df[~dup_mask].copy()
log.append(("Removed exact duplicate order-line records",
            f"{n_dupes} rows ({n_dupes/n_before*100:.2f}% of the file) were byte-for-byte "
            f"duplicates of another row (same order, product, customer, sales, profit) — a "
            f"classic export/merge artifact.",
            "Duplicated lines double-count revenue and profit for the affected orders, "
            "inflating every KPI that sums Sales or Profit."))

# 5. Fix invalid records -------------------------------------------------------------
n_zero_qty = int((df["Quantity"] == 0).sum())
df = df[df["Quantity"] > 0].copy()
log.append(("Removed records with Quantity = 0",
            f"{n_zero_qty} line items had zero units sold with non-zero Sales/Profit — an "
            f"impossible combination that indicates a data-entry or export error, not a real transaction.",
            "Including these would distort per-unit metrics (Sales/Quantity, Profit/Quantity) "
            "with divide-by-zero or nonsensical unit economics."))

# 6. Outlier handling -----------------------------------------------------------------
sales_q99 = df["Sales"].quantile(0.99)
n_outliers = int((df["Sales"] > sales_q99 * 3).sum())
df["Is_Sales_Outlier"] = df["Sales"] > sales_q99 * 3
log.append(("Flagged (not deleted) extreme Sales outliers with a new Is_Sales_Outlier column",
            f"{n_outliers} orders had Sales more than 3x the 99th percentile — plausible as "
            f"genuine large bulk/enterprise orders (e.g. bulk Copiers), not necessarily errors.",
            "Deleting them could discard legitimate high-value enterprise deals; ignoring them "
            "unflagged risks a handful of records swinging category/city averages."))

# 7. Calculated fields -----------------------------------------------------------------
df["Order Year"] = df["Order Date"].dt.year
df["Order Month"] = df["Order Date"].dt.to_period("M").astype(str)
df["Order Month Name"] = df["Order Date"].dt.strftime("%B")
df["Order Weekday"] = df["Order Date"].dt.day_name()
df["Shipping Lag (Days)"] = (df["Ship Date"] - df["Order Date"]).dt.days
df["Unit Price"] = (df["Sales"] / df["Quantity"]).round(2)
df["Profit Margin %"] = np.where(df["Sales"] != 0, (df["Profit"] / df["Sales"] * 100).round(2), 0)
df["Discount Band"] = pd.cut(df["Discount"], bins=[-0.01, 0, 0.15, 0.3, 1],
                              labels=["No Discount", "Low (0-15%)", "Medium (15-30%)", "High (30%+)"])
log.append(("Created calculated fields: Order Year/Month/Weekday, Shipping Lag (Days), "
            "Unit Price, Profit Margin %, Discount Band",
            "None of these existed in the raw export but every one of them is required to "
            "answer the business questions (seasonality, delivery speed, profitability by "
            "discount level).",
            "Without them, every trend/segmentation question would require re-deriving the "
            "same fields ad hoc and inconsistently each time."))

df.to_csv("/home/claude/project/processed_data.csv", index=False)

# ================= ANALYSIS / INSIGHTS =================
res = {}
res["raw_rows"] = int(n_raw_rows)
res["raw_cols"] = int(n_raw_cols)
res["processed_rows"] = int(len(df))
res["processed_cols"] = int(df.shape[1])
res["dupes_removed"] = n_dupes
res["zero_qty_removed"] = n_zero_qty
res["postal_missing_pct"] = postal_missing_pct
res["outliers_flagged"] = n_outliers
res["date_min"] = str(df["Order Date"].min().date())
res["date_max"] = str(df["Order Date"].max().date())

total_sales = df["Sales"].sum()
total_profit = df["Profit"].sum()
res["total_sales"] = round(total_sales, 2)
res["total_profit"] = round(total_profit, 2)
res["overall_margin_pct"] = round(total_profit / total_sales * 100, 2)
res["total_orders"] = df["Order ID"].nunique()
res["total_customers"] = df["Customer ID"].nunique()
res["avg_order_value"] = round(total_sales / res["total_orders"], 2)

# Insight 1: Category profitability
cat = df.groupby("Category").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"),
                                  Orders=("Order ID", "nunique")).reset_index()
cat["Margin %"] = (cat["Profit"] / cat["Sales"] * 100).round(2)
res["by_category"] = cat.round(2).to_dict("records")

# Insight 2: Sub-category profitability (loss-makers)
subcat = df.groupby("Sub-Category").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"),
                                         AvgDiscount=("Discount", "mean")).reset_index()
subcat["Margin %"] = (subcat["Profit"] / subcat["Sales"] * 100).round(2)
subcat = subcat.sort_values("Margin %")
res["worst_subcategories"] = subcat.head(3).round(3).to_dict("records")
res["best_subcategories"] = subcat.sort_values("Margin %", ascending=False).head(3).round(3).to_dict("records")

# Insight 3: Discount vs profit relationship
disc = df.groupby("Discount Band", observed=True).agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"),
                                    Orders=("Order ID", "nunique")).reset_index()
disc["Margin %"] = (disc["Profit"] / disc["Sales"] * 100).round(2)
res["by_discount_band"] = disc.round(2).to_dict("records")

# Insight 4: Regional / market performance
mkt = df.groupby("Market").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"),
                                Orders=("Order ID", "nunique")).reset_index()
mkt["Margin %"] = (mkt["Profit"] / mkt["Sales"] * 100).round(2)
mkt = mkt.sort_values("Sales", ascending=False)
res["by_market"] = mkt.round(2).to_dict("records")

# Insight 5: Monthly seasonality
month_order = ["January","February","March","April","May","June","July","August",
               "September","October","November","December"]
seas = df.groupby("Order Month Name").agg(Sales=("Sales", "sum")).reindex(month_order).reset_index()
res["seasonality"] = seas.round(2).to_dict("records")
res["peak_month"] = seas.loc[seas["Sales"].idxmax(), "Order Month Name"]
res["low_month"] = seas.loc[seas["Sales"].idxmin(), "Order Month Name"]

# Insight 6: Ship mode
ship = df.groupby("Ship Mode").agg(Orders=("Order ID", "nunique"),
                                    AvgLag=("Shipping Lag (Days)", "mean")).reset_index()
ship = ship.sort_values("Orders", ascending=False)
res["by_ship_mode"] = ship.round(2).to_dict("records")

# Insight 7: Segment performance
seg = df.groupby("Segment").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"),
                                 Customers=("Customer ID", "nunique")).reset_index()
seg["Margin %"] = (seg["Profit"] / seg["Sales"] * 100).round(2)
res["by_segment"] = seg.round(2).to_dict("records")

# Insight 8: Top cities
city = df.groupby("City").agg(Sales=("Sales", "sum")).reset_index().sort_values("Sales", ascending=False)
res["top_cities"] = city.head(10).round(2).to_dict("records")
res["bottom_cities"] = city[city["Sales"] > 0].sort_values("Sales").head(5).round(2).to_dict("records")

# Insight 9: Customer concentration (Pareto)
cust = df.groupby("Customer ID").agg(Sales=("Sales", "sum")).sort_values("Sales", ascending=False)
cust["cum_pct"] = cust["Sales"].cumsum() / cust["Sales"].sum() * 100
n_cust_for_80pct = int((cust["cum_pct"] <= 80).sum()) + 1
pct_customers_80 = round(n_cust_for_80pct / len(cust) * 100, 1)
res["pareto_customers_pct_for_80pct_sales"] = pct_customers_80

# Insight 10 (SURPRISE): Table sub-category — high sales, negative margin
tables = subcat[subcat["Sub-Category"] == "Tables"].iloc[0]
res["surprise_subcat"] = {k: (round(v, 3) if isinstance(v, (int, float, np.floating)) else v) for k, v in tables.to_dict().items()}

# High-discount high-sales but loss segment cross tab
cross = df.groupby(["Sub-Category", "Discount Band"], observed=True).agg(
    Profit=("Profit", "sum"), Sales=("Sales", "sum")).reset_index()
tables_cross = cross[cross["Sub-Category"] == "Tables"]
res["tables_by_discount"] = tables_cross.round(2).to_dict("records")

with open("/home/claude/project/results.json", "w") as f:
    json.dump(res, f, indent=2, default=str)

with open("/home/claude/project/cleaning_log.json", "w") as f:
    json.dump(log, f, indent=2)

print("TOTAL SALES:", res["total_sales"], "TOTAL PROFIT:", res["total_profit"], "MARGIN%:", res["overall_margin_pct"])
print("Peak month:", res["peak_month"], "| Low month:", res["low_month"])
print("Worst subcat:", res["worst_subcategories"])
print("Best subcat:", res["best_subcategories"])
print("Dupes removed:", n_dupes, "| Zero-qty removed:", n_zero_qty, "| Postal missing %:", postal_missing_pct)
print("Rows raw->processed:", n_raw_rows, "->", len(df))
