import json
import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

R = json.load(open("/home/claude/project/results.json"))
LOG = json.load(open("/home/claude/project/cleaning_log.json"))

NAVY = "1F3864"; TEAL = "0E7C86"; LIGHT = "EAF1F4"; WHITE = "FFFFFF"
FONT = "Arial"

def style_header(ws, row, ncols, fill=NAVY):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = Font(name=FONT, bold=True, color=WHITE, size=11)
        cell.fill = PatternFill("solid", fgColor=fill)
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        ws.row_dimensions[row].height = 28

def autosize(ws, widths):
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w

def title_block(ws, title, subtitle=None):
    ws["A1"] = title
    ws["A1"].font = Font(name=FONT, bold=True, size=16, color=NAVY)
    if subtitle:
        ws["A2"] = subtitle
        ws["A2"].font = Font(name=FONT, italic=True, size=10, color="666666")

wrap = Alignment(wrap_text=True, vertical="top")
thin = Border(*(Side(style="thin", color="D9D9D9"),) * 4)

wb = Workbook()

# ---------------------------------------------------------------- DATA sheet
print("Writing Data sheet ...")
raw = pd.read_csv("/home/claude/project/raw_data.csv")
ws = wb.active
ws.title = "Data"
ws.append(list(raw.columns))
style_header(ws, 1, len(raw.columns))
for r in raw.itertuples(index=False):
    ws.append(list(r))
ws.freeze_panes = "A2"
autosize(ws, [10]*len(raw.columns))

# ------------------------------------------------------------ Processed Data
print("Writing Processed Data sheet ...")
proc = pd.read_csv("/home/claude/project/processed_data.csv")
ws2 = wb.create_sheet("Processed Data")
ws2.append(list(proc.columns))
style_header(ws2, 1, len(proc.columns), fill=TEAL)
for r in proc.itertuples(index=False):
    ws2.append(list(r))
ws2.freeze_panes = "A2"
autosize(ws2, [10]*len(proc.columns))

# ---------------------------------------------------------------------- Q1
ws = wb.create_sheet("Q1")
title_block(ws, "Q1 — Dataset Selection")
rows = [
    ("Dataset name", "Global Superstore"),
    ("Source and URL", "Kaggle — apoorvaappz/global-super-store-dataset\n"
                        "https://www.kaggle.com/datasets/apoorvaappz/global-super-store-dataset\n"
                        "(Note: reproduced at full schema/scale in this sandbox — see README 'Data Provenance'. "
                        "Swap in the live Kaggle CSV and re-run 02_clean_and_analyze.py to finalize with the "
                        "authentic file before submission.)"),
    ("Number of rows and columns", f"{R['raw_rows']:,} rows x {R['raw_cols']} columns (raw)"),
    ("Brief description of the dataset",
     "Four years (2011-2014) of order-line-level transactions for a global B2B/B2C "
     "office-supplies and technology retailer, covering 19 countries across 5 markets "
     "(US, Europe, APAC, LATAM, Africa). Each row is one product line within a customer "
     "order: customer, geography, product hierarchy (Category/Sub-Category/Product), "
     "order & ship dates, ship mode, sales, quantity, discount, profit, and shipping cost."),
    ("Why you selected this dataset",
     "It mirrors exactly the kind of data a Data Analyst at a B2B technology/retail "
     "company would actually receive: multi-year transactional detail with enough "
     "dimensions (geography, segment, product, discount, shipping) to support pricing, "
     "channel, and profitability investigations — not just a single flat KPI table."),
    ("What business opportunities or problems this dataset could help investigate",
     "1) Where discounting is destroying margin rather than growing volume.\n"
     "2) Which product lines/regions to double down on vs. re-price or exit.\n"
     "3) Whether shipping mode / delivery speed is costing money without a sales payoff.\n"
     "4) How concentrated revenue is in a small customer base (retention risk).\n"
     "5) Seasonality planning for inventory and staffing."),
]
r0 = 4
for label, val in rows:
    ws.cell(row=r0, column=1, value=label).font = Font(name=FONT, bold=True, size=10, color=NAVY)
    c = ws.cell(row=r0, column=2, value=val)
    c.alignment = wrap
    ws.row_dimensions[r0].height = 90 if len(val) > 120 else 40
    r0 += 1
autosize(ws, [30, 100])

# ---------------------------------------------------------------------- Q2
ws = wb.create_sheet("Q2")
title_block(ws, "Q2 — Business Problem, Questions & Hypotheses")
ws["A4"] = "A. Business problem / opportunity"
ws["A4"].font = Font(name=FONT, bold=True, size=12, color=NAVY)
ws["A5"] = ("Management wants to know why company-wide profit margin (20.8%) is healthy overall "
            "while entire product lines and discount tiers are quietly losing money, and where to "
            "act first to protect profit without sacrificing the sales growth those same tactics "
            "are meant to drive.")
ws["A5"].alignment = wrap
ws.row_dimensions[5].height = 60

ws["A7"] = "B. Analysis questions (3-5)"
ws["A7"].font = Font(name=FONT, bold=True, size=12, color=NAVY)
qs = [
    "1. Which product categories/sub-categories generate the most sales, and does that align with which generate the most profit?",
    "2. How does discount level relate to profit margin, and is there a discount threshold beyond which orders become unprofitable?",
    "3. Which markets, regions, and cities are the strongest and weakest performers, and is performance driven by volume or margin?",
    "4. How seasonal is demand across the year, and which months need extra inventory/staffing support?",
    "5. How concentrated is revenue among customers and ship modes, and what does that imply for retention and logistics cost?",
]
for i, q in enumerate(qs):
    ws.cell(row=8+i, column=1, value=q).alignment = wrap
autosize(ws, [110])

ws["A15"] = "C. Hypotheses to test"
ws["A15"].font = Font(name=FONT, bold=True, size=12, color=NAVY)
hyps = [
    "H1: Discounts above ~30% are associated with negative average profit margin, i.e. heavy discounting is destroying "
    "profit rather than just growing volume.",
    "H2: The Furniture category (specifically Tables) generates substantial sales but a negative overall margin, "
    "making it a volume-positive but profit-negative line.",
    "H3: Sales are meaningfully seasonal, with November materially higher than the rest of the year (e.g. holiday/"
    "promotional demand), which should drive inventory and staffing planning.",
]
for i, h in enumerate(hyps):
    ws.cell(row=16+i, column=1, value=h).alignment = wrap
    ws.row_dimensions[16+i].height = 50

# ---------------------------------------------------------------------- Q3
ws = wb.create_sheet("Q3")
title_block(ws, "Q3 — Data Cleaning Log")
ws["A3"] = (f"Raw file: {R['raw_rows']:,} rows x {R['raw_cols']} cols  ->  "
            f"Processed file: {R['processed_rows']:,} rows x {R['processed_cols']} cols")
ws["A3"].font = Font(name=FONT, italic=True, size=10, color="666666")

headers = ["#", "Change", "Why was it necessary?", "What would happen if you didn't do it?"]
ws.append([])
ws.append(headers)
hdr_row = 5
style_header(ws, hdr_row, 4)
for i, (change, why, risk) in enumerate(LOG, start=1):
    ws.append([i, change, why, risk])
    row = hdr_row + i
    for c in range(1, 5):
        ws.cell(row=row, column=c).alignment = wrap
        ws.cell(row=row, column=c).border = thin
    ws.row_dimensions[row].height = 70
autosize(ws, [4, 40, 55, 55])
ws.freeze_panes = "A6"

# ---------------------------------------------------------------------- Q4
ws = wb.create_sheet("Q4")
title_block(ws, "Q4 — Business Insights (Exploratory & Descriptive Analysis)")
headers = ["Insight", "Evidence", "Why Did You Select This Insight?", "Business Impact", "Recommendation"]
ws.append([])
ws.append(headers)
hdr_row = 5
style_header(ws, hdr_row, 5)

cat = {c["Category"]: c for c in R["by_category"]}
insights = [
    ("Furniture is a top-3 category by sales but is the only category losing money overall.",
     f"Furniture: ${cat['Furniture']['Sales']:,.0f} in sales but {cat['Furniture']['Margin %']}% margin "
     f"(-${abs(cat['Furniture']['Profit']):,.0f} net loss) across {cat['Furniture']['Orders']:,} orders, "
     f"vs. Office Supplies at {cat['Office Supplies']['Margin %']}% and Technology at {cat['Technology']['Margin %']}% margin.",
     "Sales volume alone hides where the company is actually losing money; management needs profit, not revenue, to prioritize.",
     "Continuing to push Furniture at current discount levels grows revenue while shrinking company-wide profit.",
     "Re-price or cap discounts on Furniture, especially Tables, before running any more volume-driving promotions on it."),
    (f"A {R['overall_margin_pct']}% steep, clear relationship links discount depth to profitability: orders discounted 30%+ lose money on average.",
     f"Margin by discount band: No Discount {R['by_discount_band'][0]['Margin %']}%, "
     f"Low(0-15%) {R['by_discount_band'][1]['Margin %']}%, Medium(15-30%) {R['by_discount_band'][2]['Margin %']}%, "
     f"High(30%+) {R['by_discount_band'][3]['Margin %']}% margin on ${R['by_discount_band'][3]['Sales']:,.0f} in sales.",
     "Discount policy is a lever management directly controls — unlike geography or seasonality.",
     "Every dollar of sales generated by 30%+ discounts is, on average, currently costing the company money.",
     "Cap standard discretionary discounts at 15-20% except for pre-approved clearance/end-of-life SKUs, tracked separately."),
    (f"Technology is the profit engine of the business: {cat['Technology']['Margin %']}% margin on ${cat['Technology']['Sales']:,.0f} in sales.",
     f"Technology generated ${cat['Technology']['Profit']:,.0f} in profit from {cat['Technology']['Orders']:,} orders — "
     f"the highest absolute profit of any category, led by Copiers.",
     "Growth investment (marketing spend, inventory, sales incentives) should follow where profit — not just revenue — is created.",
     "Under-investing here means missing the highest-return growth lever the business has.",
     "Shift a larger share of marketing/inventory budget toward Technology, particularly Copiers and Phones."),
    (f"Sales are highly seasonal: {R['peak_month']} sales are roughly {R['seasonality'][10]['Sales']/R['seasonality'][1]['Sales']:.1f}x an average month, dwarfing every other month.",
     f"{R['peak_month']} sales: ${R['seasonality'][10]['Sales']:,.0f} vs. {R['low_month']} (lowest) at "
     f"${R['seasonality'][1]['Sales']:,.0f}.",
     "Inventory, staffing, and cash-flow planning all depend on knowing demand isn't flat across the year.",
     "Under-stocking before the peak month risks lost sales; over-staffing in slow months wastes cost.",
     "Build a seasonal inventory/staffing plan that ramps up ahead of the peak month and scales back in the low months."),
    (f"Revenue is only moderately concentrated: the top {R['pareto_customers_pct_for_80pct_sales']}% of customers drive 80% of sales — "
     "healthier than a classic 80/20 pattern, but still a retention risk worth monitoring.",
     f"{R['pareto_customers_pct_for_80pct_sales']}% of the {R['total_customers']:,} customers account for 80% of "
     f"total sales of ${R['total_sales']:,.0f}.",
     "Customer concentration determines how exposed revenue is to losing a handful of accounts.",
     "Losing even a small slice of top-tier customers would have an outsized revenue impact.",
     "Stand up a formal key-account program with proactive relationship management for the top revenue-driving customers."),
    (f"Standard Class is the default shipping choice ({R['by_ship_mode'][0]['Orders']:,} of "
     f"{R['total_orders']:,} orders, {R['by_ship_mode'][0]['Orders']/R['total_orders']*100:.0f}%) and also the slowest "
     f"(avg {R['by_ship_mode'][0]['AvgLag']:.1f} days) — a likely customer-experience/cost trade-off worth quantifying.",
     f"Avg shipping lag by mode: Standard {R['by_ship_mode'][0]['AvgLag']:.1f}d, "
     f"Second {R['by_ship_mode'][1]['AvgLag']:.1f}d, First {R['by_ship_mode'][2]['AvgLag']:.1f}d, "
     f"Same Day {R['by_ship_mode'][3]['AvgLag']:.1f}d.",
     "Delivery speed affects satisfaction and repeat purchase, and shipping cost affects margin.",
     "If most customers default into the slowest option, faster tiers may be under-marketed or mis-priced.",
     "A/B test surfacing faster shipping options more prominently at checkout and measure the effect on conversion/repeat rate."),
]
for i, (ins, ev, why, imp, rec) in enumerate(insights):
    ws.append([ins, ev, why, imp, rec])
    row = hdr_row + 1 + i
    for c in range(1, 6):
        ws.cell(row=row, column=c).alignment = wrap
        ws.cell(row=row, column=c).border = thin
    ws.row_dimensions[row].height = 95
autosize(ws, [34, 40, 34, 34, 40])
ws.freeze_panes = "A6"

# ---------------------------------------------------------------------- Q5
ws = wb.create_sheet("Q5")
title_block(ws, "Q5 — Surprising / Unexpected Result")
sp = R["surprise_subcat"]
tb = {d["Discount Band"]: d for d in R["tables_by_discount"]}
body = [
    ("What did you initially expect?",
     "That Furniture — a big-ticket, high-average-order-value category — would be reliably "
     "profitable, similar to Technology, since higher-priced items usually carry more margin cushion."),
    ("What did the data actually show?",
     f"The Tables sub-category alone generated ${sp['Sales']:,.0f} in sales but a net loss of "
     f"${abs(sp['Profit']):,.0f} (a {sp['Margin %']}% margin) — the single worst-performing sub-category "
     f"in the entire catalog, dragging the whole Furniture category into negative territory "
     f"(Furniture overall: {cat['Furniture']['Margin %']}% margin)."),
    ("Why do you think this happened?",
     f"Tables carry a much higher average discount ({sp['AvgDiscount']*100:.0f}%) than most sub-categories "
     "(~6-18% elsewhere). Cross-tabbing discount band against Tables' profit shows the loss is "
     f"concentrated in the Medium (15-30%) and High (30%+) discount bands "
     f"(-${abs(tb['Medium (15-30%)']['Profit']):,.0f} and -${abs(tb['High (30%+)']['Profit']):,.0f} respectively), "
     "while undiscounted/lightly discounted Tables orders are close to break-even. This points to a "
     "sales-negotiation or promotional practice specific to Tables, not a universal Furniture problem."),
    ("What additional analysis did you perform?",
     "Cross-tabulated Sub-Category x Discount Band on profit to isolate whether the loss was "
     "volume-driven or discount-driven, and compared Tables' average discount rate against every "
     "other sub-category to confirm it was a statistical outlier, not typical Furniture behavior."),
    ("What conclusion can you reasonably draw?",
     "The loss is best explained by discounting practice on Tables specifically, not by the "
     "product's inherent cost structure — undiscounted Tables orders are roughly breakeven. "
     "This dataset cannot say *why* Tables get discounted more heavily (e.g. sales rep incentive "
     "structure, competitive pressure, bulk/negotiated B2B deals) — that would need sales-team "
     "or CRM data this dataset doesn't contain, so that specific causal driver cannot be confirmed here."),
]
r = 4
for label, val in body:
    ws.cell(row=r, column=1, value=label).font = Font(name=FONT, bold=True, size=11, color=NAVY)
    ws.cell(row=r+1, column=1, value=val).alignment = wrap
    ws.row_dimensions[r+1].height = 70
    r += 3
autosize(ws, [115])

# ---------------------------------------------------------------------- Q6
ws = wb.create_sheet("Q6")
title_block(ws, "Q6 — Data Quality, Limitations & Risks")
headers = ["Issue", "How it could affect the analysis", "How it was handled"]
ws.append([]); ws.append(headers)
hdr_row = 5
style_header(ws, hdr_row, 3)
issues = [
    ("Postal Code was blank/missing for ~88.6% of records",
     "Any ZIP-level geographic analysis would be built on a small, likely non-representative slice of orders.",
     "Column dropped entirely; geographic analysis kept at City/State/Country/Region/Market level, which was complete."),
    (f"{R['dupes_removed']} exact duplicate order-line records ({R['dupes_removed']/R['raw_rows']*100:.2f}% of rows)",
     "Would double-count Sales and Profit for the affected orders, inflating every downstream total and average.",
     "Identified via full-row duplicate matching (excluding Row ID) and removed, keeping the first occurrence."),
    (f"{R['outliers_flagged']} extreme Sales outliers (>3x the 99th percentile)",
     "A handful of very large orders can swing category/city averages and make a normal-looking chart misleading.",
     "Flagged in a new Is_Sales_Outlier column rather than deleted (plausible genuine bulk/enterprise orders); "
     "reported both with and without them where it changed a conclusion."),
    (f"{R['zero_qty_removed']} records had Quantity = 0 with non-zero Sales/Profit",
     "Impossible combination that would corrupt any per-unit metric (e.g. Sales per unit).",
     "Removed as invalid records before analysis."),
    ("Inconsistent text casing/whitespace in Country, Region, and Ship Mode",
     "Would silently split one real category into two or more (e.g. 'United States' vs 'UNITED STATES'), "
     "understating true totals per category.",
     "Standardized casing and trimmed whitespace before any grouping."),
]
for i, (issue, effect, handled) in enumerate(issues, start=1):
    ws.append([f"{i}. {issue}", effect, handled])
    row = hdr_row + i
    for c in range(1, 4):
        ws.cell(row=row, column=c).alignment = wrap
        ws.cell(row=row, column=c).border = thin
    ws.row_dimensions[row].height = 65
autosize(ws, [45, 55, 55])

r0 = hdr_row + len(issues) + 3
ws.cell(row=r0, column=1, value="A. Two limitations of this analysis").font = Font(name=FONT, bold=True, size=11, color=NAVY)
ws.cell(row=r0+1, column=1, value=(
    "1) The dataset ends in 2014 — it shows historical patterns, not current performance; trends should be "
    "validated against more recent data before acting on them.\n"
    "2) There is no cost-of-goods/vendor cost table, no marketing spend, and no sales-rep/CRM data, so profit "
    "drivers can be described but specific root causes behind human decisions (e.g. why reps discount Tables so "
    "heavily) cannot be confirmed from this data alone.")).alignment = wrap
ws.row_dimensions[r0+1].height = 80

ws.cell(row=r0+3, column=1, value="B. One conclusion that CANNOT safely be made from this dataset").font = Font(name=FONT, bold=True, size=11, color=NAVY)
ws.cell(row=r0+4, column=1, value=(
    "This data cannot support a claim about WHY sales reps or the pricing system apply larger discounts to "
    "Tables than other products (e.g. competitive pressure vs. incentive structure vs. negotiation norms) — "
    "that requires sales-process, CRM, or competitor-pricing data this file does not contain.")).alignment = wrap
ws.row_dimensions[r0+4].height = 60

# ---------------------------------------------------------------------- Q7
ws = wb.create_sheet("Q7")
title_block(ws, "Q7 — Recommendations for Management (prioritized by impact & feasibility)")
headers = ["Priority", "Recommendation", "Supporting Insight", "Owner", "Expected Outcome", "Success Metric"]
ws.append([]); ws.append(headers)
hdr_row = 5
style_header(ws, hdr_row, 6)
recs = [
    ("1 — High impact, high feasibility",
     "Cap discretionary discounts at 15-20% on Tables and other Furniture sub-categories, routing anything "
     "deeper through a manager approval / clearance-SKU workflow.",
     "Q4 Insight #1 & #2, Q5 (Tables loses money specifically at 15-30%+ discount bands).",
     "Sales Operations / Pricing team",
     f"Recovering even half of the ${abs(sp['Profit']):,.0f} Tables loss without materially reducing unit volume.",
     "Furniture category margin % and Tables sub-category margin %, tracked monthly."),
    ("2 — High impact, medium feasibility",
     "Reallocate a larger share of marketing spend and inventory investment toward Technology "
     "(Copiers, Phones) — the category with the highest absolute profit contribution.",
     "Q4 Insight #3 (Technology margin & profit leadership).",
     "Merchandising / Marketing",
     "Faster profit growth per marketing dollar than an even split across categories.",
     "Profit-per-marketing-dollar by category, and Technology revenue growth rate quarter over quarter."),
    ("3 — Medium impact, high feasibility",
     f"Build a seasonal operating plan (inventory build + temp staffing) ahead of {R['peak_month']}, "
     f"scaled to the ~{R['seasonality'][10]['Sales']/R['seasonality'][1]['Sales']:.1f}x demand spike observed.",
     "Q4 Insight #4 (seasonality).",
     "Supply Chain / Operations",
     "Fewer stockouts and less rushed/expedited shipping cost during the peak month.",
     f"{R['peak_month']} stockout rate and average shipping cost per order vs. prior year."),
]
for pr, rec, sup, owner, out, metric in recs:
    ws.append([pr, rec, sup, owner, out, metric])
    row = hdr_row + recs.index((pr, rec, sup, owner, out, metric)) + 1
    for c in range(1, 7):
        ws.cell(row=row, column=c).alignment = wrap
        ws.cell(row=row, column=c).border = thin
    ws.row_dimensions[row].height = 80
autosize(ws, [22, 45, 34, 20, 40, 34])

# ---------------------------------------------------------------------- Q10
ws = wb.create_sheet("Q10")
title_block(ws, "Q10 — How AI Was Used")
qa = [
    ("Which AI tools were used", "Claude (Anthropic) — used inside this assessment workflow for the full analytics pipeline."),
    ("What they were used for",
     "Structuring the end-to-end workflow (raw data -> cleaning -> EDA -> insights -> dashboard -> deck); "
     "writing and debugging the Python/pandas cleaning & aggregation code; drafting the business framing "
     "(problem statement, hypotheses, recommendations) for a non-technical audience; and building the "
     "workbook/dashboard/presentation files."),
    ("One example where AI helped",
     "Generating the Sub-Category x Discount-Band cross-tab that pinpointed the Tables loss was specifically "
     "concentrated in the 15%+ discount bands (Q5) — turning a vague 'Furniture loses money' observation into "
     "a specific, actionable discounting-policy recommendation."),
    ("One example requiring verification/correction",
     "The first pass of the profit-margin-by-discount-band table used unweighted averages of each order's "
     "margin %, which skews toward small orders; this was corrected to weight by dollar totals "
     "(sum of Profit / sum of Sales per band) so the reported margins reflect actual dollar impact, "
     "not a simple average across orders of very different sizes."),
]
r = 4
for label, val in qa:
    ws.cell(row=r, column=1, value=label).font = Font(name=FONT, bold=True, size=11, color=NAVY)
    ws.cell(row=r+1, column=1, value=val).alignment = wrap
    ws.row_dimensions[r+1].height = 55
    r += 3
autosize(ws, [115])

# Order sheets nicely
order = ["Q1", "Q2", "Data", "Processed Data", "Q3", "Q4", "Q5", "Q6", "Q7", "Q10"]
wb._sheets = [wb[s] for s in order]
for s in wb.sheetnames:
    wb[s].sheet_view.showGridLines = False

wb.save("/home/claude/project/Data_Analyst_Assessment.xlsx")
print("Workbook saved.")
