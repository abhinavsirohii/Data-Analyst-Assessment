const pptxgen = require("pptxgenjs");
const fs = require("fs");

const R = JSON.parse(fs.readFileSync("/home/claude/project/results.json", "utf8"));

const NAVY = "1F3864", TEAL = "0E7C86", GOLD = "D4A017", RED = "C0392B", GREY = "6B7A8F", LIGHT = "F4F6F8", WHITE="FFFFFF", INK="1B2733";

let pres = new pptxgen();
pres.layout = "LAYOUT_WIDE"; // 13.3 x 7.5
const W = 13.33, H = 7.5;

function baseSlide(bg) {
  let s = pres.addSlide();
  s.background = { color: bg || WHITE };
  return s;
}

function footer(s, pageNum, dark) {
  s.addText("Global Superstore — Management Review", {
    x: 0.5, y: H - 0.42, w: 6, h: 0.3, fontFace: "Arial", fontSize: 9,
    color: dark ? "9FB3D1" : "9AA7B4", isTextBox: true,
  });
  s.addText(String(pageNum), {
    x: W - 1.0, y: H - 0.42, w: 0.5, h: 0.3, fontFace: "Arial", fontSize: 9,
    align: "right", color: dark ? "9FB3D1" : "9AA7B4", isTextBox: true,
  });
}

function kicker(s, text, color) {
  s.addText(text.toUpperCase(), {
    x: 0.6, y: 0.45, w: 8, h: 0.35, fontFace: "Arial", fontSize: 12, bold: true,
    color: color || TEAL, charSpacing: 2, isTextBox: true,
  });
}

function pill(s, x, y, w, h, color) {
  s.addShape("roundRect", { x, y, w, h, rectRadius: h/2, fill: { color }, line: { type: "none" } });
}

/* ---------------- SLIDE 1: TITLE / BUSINESS PROBLEM ---------------- */
{
  let s = baseSlide(NAVY);
  s.addShape("rect", { x:0, y:0, w:W, h:H, fill:{color:NAVY}, line:{type:"none"} });
  // decorative soft circles motif (repeated across deck as the visual motif)
  s.addShape("ellipse", { x: W-3.2, y: -1.4, w: 5, h: 5, fill: { color: "26426B" }, line: { type: "none" } });
  s.addShape("ellipse", { x: W-1.6, y: H-2.2, w: 3.2, h: 3.2, fill: { color: "16304F" }, line: { type: "none" } });

  s.addText("BUSINESS PROBLEM", { x:0.7, y:0.7, w:6, h:0.4, fontFace:"Arial", fontSize:13, bold:true, color: GOLD, charSpacing:2, isTextBox:true });
  s.addText("Where is discounting quietly\nerasing our profit?", {
    x:0.7, y:1.15, w:9.5, h:2.0, fontFace:"Cambria", fontSize:40, bold:true, color: WHITE, isTextBox:true, lineSpacingMultiple: 1.05,
  });
  s.addText(
    "Company-wide margin looks healthy at 20.8% — but underneath that number, one full product "+
    "category and one entire discount tier are losing money on every sale. This review identifies "+
    "exactly where, why, and what to do about it, using four years of global order-line data "+
    "(2011–2014, 19 countries, 51,282 order lines).",
    { x:0.7, y:3.15, w:8.6, h:1.7, fontFace:"Arial", fontSize:15, color:"D7E1EE", isTextBox:true, lineSpacingMultiple:1.25 }
  );

  const stats = [
    ["$76.1M", "Total Sales"], ["$15.9M", "Total Profit"], ["20.8%", "Overall Margin"], ["19,172", "Orders Analyzed"]
  ];
  let sx = 0.7, sw = 2.7, gap = 0.25;
  stats.forEach(([v,l], i) => {
    let x = sx + i*(sw+gap);
    s.addShape("roundRect", { x, y:5.15, w:sw, h:1.5, rectRadius:0.1, fill:{color:"16304F"}, line:{color:"2C4A73", width:1} });
    s.addText(v, { x, y:5.28, w:sw, h:0.7, align:"center", fontFace:"Arial", fontSize:26, bold:true, color:GOLD, isTextBox:true });
    s.addText(l, { x, y:5.95, w:sw, h:0.5, align:"center", fontFace:"Arial", fontSize:11.5, color:"AFC2DA", isTextBox:true });
  });
  footer(s, 1, true);
}

/* ---------------- SLIDE 2: DATA & METHODOLOGY ---------------- */
{
  let s = baseSlide(WHITE);
  kicker(s, "Data & Methodology");
  s.addText("A full-funnel view of the data, cleaned once, trusted everywhere", {
    x:0.6, y:0.82, w:11.5, h:0.8, fontFace:"Cambria", fontSize:26, bold:true, color:NAVY, isTextBox:true,
  });

  const steps = [
    ["01", "Source", "Global Superstore dataset — 51,290 order-line records x 24 fields, spanning 19 countries and 4 years (2011–2014)."],
    ["02", "Clean", "Fixed data types, standardized text, removed 205 duplicate rows and 8 invalid zero-quantity records, dropped an 88.6%-empty postal code field."],
    ["03", "Enrich", "Built calculated fields: order year/month/weekday, shipping lag, unit price, profit margin %, and discount bands."],
    ["04", "Analyze", "Explored profitability by category, discount level, market, city, segment, and season using Python (pandas / matplotlib)."],
  ];
  let colW = 2.85, gap = 0.22, x0 = 0.6, y0 = 2.0;
  steps.forEach(([num, title, desc], i) => {
    let x = x0 + i*(colW+gap);
    s.addShape("roundRect", { x, y:y0, w:colW, h:3.9, rectRadius:0.08, fill:{color:LIGHT}, line:{color:"E3E7EB", width:1} });
    s.addShape("ellipse", { x:x+0.25, y:y0+0.3, w:0.65, h:0.65, fill:{color: i%2===0?NAVY:TEAL}, line:{type:"none"} });
    s.addText(num, { x:x+0.25, y:y0+0.3, w:0.65, h:0.65, align:"center", valign:"middle", fontFace:"Arial", fontSize:16, bold:true, color:WHITE, isTextBox:true });
    s.addText(title, { x:x+0.25, y:y0+1.1, w:colW-0.5, h:0.45, fontFace:"Arial", fontSize:16, bold:true, color:NAVY, isTextBox:true });
    s.addText(desc, { x:x+0.25, y:y0+1.6, w:colW-0.5, h:2.1, fontFace:"Arial", fontSize:11.5, color:INK, isTextBox:true, lineSpacingMultiple:1.25 });
  });

  s.addText("Tools: Python (pandas, NumPy, Matplotlib) for cleaning & EDA · Google Sheets for the audit trail · Looker Studio for the live dashboard",
    { x:0.6, y:6.15, w:11.8, h:0.5, fontFace:"Arial", fontSize:11, italic:true, color:GREY, isTextBox:true });
  footer(s, 2, false);
}

/* ---------------- SLIDE 3: KEY FINDINGS ---------------- */
{
  let s = baseSlide(WHITE);
  kicker(s, "Key Findings");
  s.addText("Four things management should know right now", {
    x:0.6, y:0.82, w:11.5, h:0.8, fontFace:"Cambria", fontSize:26, bold:true, color:NAVY, isTextBox:true,
  });

  const findings = [
    [TEAL, "Furniture is losing money", "The #2 category by sales ($20.0M) is the only one with negative margin (-0.6%) — driven almost entirely by Tables."],
    [RED, "Deep discounts don't pay off", "Orders discounted 30%+ lose -23.5% margin on average. Every extra discount point past ~15-20% is now working against profit."],
    [GOLD, "Technology is the profit engine", "28.2% margin on $48.3M sales — the highest absolute profit of any category, led by Copiers and Phones."],
    [NAVY, "Demand is sharply seasonal", "November sales ($17.5M) run about 3.3x an average month — inventory and staffing plans should reflect that spike."],
  ];
  let colW=2.75, gap=0.2, x0=0.6, y0=1.85;
  findings.forEach(([color,title,desc], i)=>{
    let x = x0 + i*(colW+gap);
    s.addShape("roundRect", { x, y:y0, w:colW, h:0.08, fill:{color}, line:{type:"none"} });
    s.addText(title, { x, y:y0+0.2, w:colW, h:0.65, fontFace:"Arial", fontSize:14.5, bold:true, color:NAVY, isTextBox:true, lineSpacingMultiple:1.05 });
    s.addText(desc, { x, y:y0+0.9, w:colW, h:1.35, fontFace:"Arial", fontSize:10.5, color:INK, isTextBox:true, lineSpacingMultiple:1.25 });
  });

  // chart: category sales vs margin (native chart)
  const catLabels = R.by_category.map(c=>c.Category);
  const catSales = R.by_category.map(c=>Math.round(c.Sales/1e6*10)/10);
  const catMargin = R.by_category.map(c=>c["Margin %"]);
  s.addChart(pres.ChartType.bar,
    [ { name:"Sales ($M)", labels: catLabels, values: catSales } ],
    { x:0.6, y:4.35, w:6.0, h:2.75, barDir:"col",
      showTitle:true, title:"Sales by Category ($M)", titleFontSize:12, titleColor:NAVY,
      chartColors:[TEAL], showLegend:false, showValue:true, dataLabelPosition:"outEnd", dataLabelFontSize:10,
      catAxisLabelColor:GREY, valAxisLabelColor:GREY, catGridLine:{style:"none"}, valGridLine:{color:"EDEFF2", size:1},
    });
  s.addChart(pres.ChartType.bar,
    [ { name:"Margin %", labels: catLabels, values: catMargin } ],
    { x:6.85, y:4.35, w:5.9, h:2.75, barDir:"col",
      showTitle:true, title:"Profit Margin by Category (%)", titleFontSize:12, titleColor:NAVY,
      chartColors:[RED], showLegend:false, showValue:true, dataLabelPosition:"outEnd", dataLabelFontSize:10,
      catAxisLabelColor:GREY, valAxisLabelColor:GREY, catGridLine:{style:"none"}, valGridLine:{color:"EDEFF2", size:1},
    });
  footer(s, 3, false);
}

/* ---------------- SLIDE 4: DEEP DIVE ---------------- */
{
  let s = baseSlide(WHITE);
  kicker(s, "Deep-Dive Insight", RED);
  s.addText("Tables aren't unprofitable by nature — they're unprofitable by discount", {
    x:0.6, y:0.82, w:11.8, h:0.9, fontFace:"Cambria", fontSize:24, bold:true, color:NAVY, isTextBox:true,
  });

  s.addText([
      { text: "We expected: ", options:{bold:true,color:NAVY} },
      { text: "A big-ticket category like Furniture should carry healthy margins, like Technology does.\n", options:{color:INK} },
      { text: "We found: ", options:{bold:true,color:NAVY, breakLine:true} },
      { text: "Tables alone generated $7.7M in sales but lost $1.57M (-20.3% margin) — the single worst sub-category company-wide, and the reason Furniture is unprofitable overall.", options:{color:INK} },
    ], { x:0.6, y:1.85, w:6.1, h:2.0, fontFace:"Arial", fontSize:13, isTextBox:true, lineSpacingMultiple:1.3 });

  s.addShape("roundRect", { x:0.6, y:4.0, w:6.1, h:2.55, rectRadius:0.08, fill:{color:LIGHT}, line:{color:"E3E7EB",width:1} });
  s.addText("Why it happens", { x:0.85, y:4.2, w:5.6, h:0.4, fontFace:"Arial", fontSize:14, bold:true, color:NAVY, isTextBox:true });
  s.addText(
    "Tables carry a 28% average discount vs. 6–18% for most other sub-categories. Cross-tabbing "+
    "discount band against Tables' profit shows the loss concentrates almost entirely in the Medium "+
    "(15–30%) and High (30%+) discount bands — undiscounted Tables orders are close to breakeven.\n\n"+
    "This dataset can show WHERE the loss originates but not WHY reps discount Tables so heavily "+
    "(e.g. negotiation norms vs. incentive structure) — that needs CRM/sales-process data.",
    { x:0.85, y:4.65, w:5.6, h:1.8, fontFace:"Arial", fontSize:11.5, color:INK, isTextBox:true, lineSpacingMultiple:1.3 });

  const tb = R.tables_by_discount;
  const tLabels = tb.map(d=>d["Discount Band"]);
  const tVals = tb.map(d=>Math.round(d.Profit/1000));
  s.addChart(pres.ChartType.bar,
    [{ name:"Profit ($K)", labels: tLabels, values: tVals }],
    { x:6.95, y:1.85, w:5.8, h:4.7, barDir:"col",
      showTitle:true, title:"Tables: Profit by Discount Band ($K)", titleFontSize:13, titleColor:NAVY,
      chartColors:[RED], showLegend:false, showValue:true, dataLabelPosition:"outEnd", dataLabelFontSize:10,
      catAxisLabelColor:GREY, valAxisLabelColor:GREY, catGridLine:{style:"none"}, valGridLine:{color:"EDEFF2",size:1},
      catAxisLabelFontSize:10,
    });
  footer(s, 4, false);
}

/* ---------------- SLIDE 5: RECOMMENDATIONS ---------------- */
{
  let s = baseSlide(WHITE);
  kicker(s, "Recommendations");
  s.addText("What management should do next", {
    x:0.6, y:0.82, w:11.5, h:0.8, fontFace:"Cambria", fontSize:26, bold:true, color:NAVY, isTextBox:true,
  });

  const recs = [
    ["1", NAVY, "Cap discounting on Furniture / Tables", "Limit discretionary discounts to 15–20%; route anything deeper through manager approval or a clearance-SKU workflow.", "Owner: Sales Ops / Pricing"],
    ["2", TEAL, "Re-weight investment toward Technology", "Shift a larger share of marketing spend and inventory investment to Copiers and Phones — the highest absolute profit contributors.", "Owner: Merchandising / Marketing"],
    ["3", GOLD, "Plan operations around November's peak", "Build a seasonal inventory and staffing plan ahead of the ~3.3x demand spike to avoid stockouts and rushed shipping costs.", "Owner: Supply Chain / Operations"],
  ];
  let colW=3.75, gap=0.25, x0=0.6, y0=2.0;
  recs.forEach(([num,color,title,desc,owner], i)=>{
    let x = x0 + i*(colW+gap);
    s.addShape("roundRect", { x, y:y0, w:colW, h:4.4, rectRadius:0.09, fill:{color:WHITE}, line:{color:"E3E7EB", width:1.25} });
    s.addShape("ellipse", { x:x+0.3, y:y0+0.3, w:0.6, h:0.6, fill:{color}, line:{type:"none"} });
    s.addText(num, { x:x+0.3, y:y0+0.3, w:0.6, h:0.6, align:"center", valign:"middle", fontFace:"Arial", fontSize:20, bold:true, color:WHITE, isTextBox:true });
    s.addText(title, { x:x+0.3, y:y0+1.1, w:colW-0.6, h:0.85, fontFace:"Arial", fontSize:15, bold:true, color:NAVY, isTextBox:true, lineSpacingMultiple:1.1 });
    s.addText(desc, { x:x+0.3, y:y0+1.95, w:colW-0.6, h:1.9, fontFace:"Arial", fontSize:11.5, color:INK, isTextBox:true, lineSpacingMultiple:1.3 });
    s.addText(owner, { x:x+0.3, y:y0+3.9, w:colW-0.6, h:0.4, fontFace:"Arial", fontSize:10.5, italic:true, color:GREY, isTextBox:true });
  });
  s.addText("Prioritized by business impact first, feasibility second — #1 is actionable within a single pricing-policy change.",
    { x:0.6, y:6.55, w:11.8, h:0.4, fontFace:"Arial", fontSize:11, italic:true, color:GREY, isTextBox:true });
  footer(s, 5, false);
}

/* ---------------- SLIDE 6: EXPECTED BUSINESS IMPACT ---------------- */
{
  let s = baseSlide(NAVY);
  s.addShape("ellipse", { x: -1.5, y: H-2.6, w: 4.5, h: 4.5, fill: { color: "16304F" }, line: { type: "none" } });
  kicker(s, "Expected Business Impact", GOLD);
  s.addText("What could improve, and how we'll know it worked", {
    x:0.6, y:0.82, w:11.5, h:0.8, fontFace:"Cambria", fontSize:26, bold:true, color:WHITE, isTextBox:true,
  });

  const impacts = [
    ["Recover Furniture margin", "Capping Tables discounting could recover a meaningful share of the $1.57M annual loss without materially cutting volume.", "Metric: Furniture & Tables margin %, tracked monthly"],
    ["Grow profit per marketing dollar", "Re-weighting spend to Technology should lift company profit growth faster than an even split across categories.", "Metric: Profit-per-marketing-$ by category"],
    ["Protect peak-season revenue", "A seasonal ops plan should reduce stockouts and cut rushed/expedited shipping costs during November.", "Metric: Nov. stockout rate & shipping cost / order"],
  ];
  let colW=3.75, gap=0.25, x0=0.6, y0=2.1;
  impacts.forEach(([title,desc,metric], i)=>{
    let x = x0 + i*(colW+gap);
    s.addShape("roundRect", { x, y:y0, w:colW, h:3.9, rectRadius:0.09, fill:{color:"16304F"}, line:{color:"2C4A73", width:1} });
    s.addText(title, { x:x+0.25, y:y0+0.3, w:colW-0.5, h:0.9, fontFace:"Arial", fontSize:15.5, bold:true, color:GOLD, isTextBox:true, lineSpacingMultiple:1.1 });
    s.addText(desc, { x:x+0.25, y:y0+1.25, w:colW-0.5, h:1.7, fontFace:"Arial", fontSize:11.5, color:"D7E1EE", isTextBox:true, lineSpacingMultiple:1.3 });
    s.addShape("line", { x:x+0.25, y:y0+3.0, w:colW-0.5, h:0, line:{color:"3A5A85", width:1} });
    s.addText(metric, { x:x+0.25, y:y0+3.15, w:colW-0.5, h:0.65, fontFace:"Arial", fontSize:10.5, italic:true, color:"9FB3D1", isTextBox:true });
  });
  footer(s, 6, true);
}

/* ---------------- SLIDE 7: LIMITATIONS & NEXT STEPS ---------------- */
{
  let s = baseSlide(WHITE);
  kicker(s, "Limitations & Next Steps");
  s.addText("What to be cautious about, and what to analyze next", {
    x:0.6, y:0.82, w:11.5, h:0.8, fontFace:"Cambria", fontSize:26, bold:true, color:NAVY, isTextBox:true,
  });

  s.addShape("roundRect", { x:0.6, y:1.95, w:5.85, h:4.35, rectRadius:0.08, fill:{color:LIGHT}, line:{color:"E3E7EB",width:1} });
  s.addText("Be cautious about", { x:0.85, y:2.15, w:5.3, h:0.45, fontFace:"Arial", fontSize:15, bold:true, color:RED, isTextBox:true });
  const cautions = [
    "Data runs through 2014 — validate these patterns against current data before committing budget.",
    "No cost-of-goods, marketing-spend, or CRM/sales-rep data exists here, so root causes behind discounting behavior can't be confirmed from this dataset alone.",
    "A small number of very large ('outlier') orders were flagged, not deleted — they can still swing category averages.",
    "We cannot conclude WHY Tables get discounted more than other products — only that they do, and where it hurts profit.",
  ];
  let cy = 2.75;
  cautions.forEach(c=>{
    s.addShape("ellipse", { x:0.9, y:cy+0.06, w:0.09, h:0.09, fill:{color:RED}, line:{type:"none"} });
    s.addText(c, { x:1.15, y:cy-0.08, w:5.0, h:0.85, fontFace:"Arial", fontSize:11, color:INK, isTextBox:true, lineSpacingMultiple:1.25 });
    cy += 0.9;
  });

  s.addShape("roundRect", { x:6.85, y:1.95, w:5.9, h:4.35, rectRadius:0.08, fill:{color:"EAF6F5"}, line:{color:"CFEBE8",width:1} });
  s.addText("Analyze next", { x:7.1, y:2.15, w:5.4, h:0.45, fontFace:"Arial", fontSize:15, bold:true, color:TEAL, isTextBox:true });
  const nexts = [
    "Pull sales-rep / CRM data to understand the human decisions behind Tables' heavy discounting.",
    "Re-run this analysis on 2023–2025 data to confirm these patterns still hold today.",
    "Build customer-level cohort analysis to test retention risk in the top revenue-driving accounts.",
    "Pilot the 15–20% discount cap on Tables in one region first, and measure the before/after margin change.",
  ];
  let ny = 2.75;
  nexts.forEach(n=>{
    s.addShape("ellipse", { x:7.15, y:ny+0.06, w:0.09, h:0.09, fill:{color:TEAL}, line:{type:"none"} });
    s.addText(n, { x:7.4, y:ny-0.08, w:5.1, h:0.85, fontFace:"Arial", fontSize:11, color:INK, isTextBox:true, lineSpacingMultiple:1.25 });
    ny += 0.9;
  });
  footer(s, 7, false);
}

pres.writeFile({ fileName: "/home/claude/project/Global_Superstore_Management_Presentation.pptx" })
  .then(() => console.log("Deck written."));
