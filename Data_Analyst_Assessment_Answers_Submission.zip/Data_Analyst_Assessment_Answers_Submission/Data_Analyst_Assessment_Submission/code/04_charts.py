import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick

R = json.load(open("/home/claude/project/results.json"))
NAVY = "#1F3864"; TEAL = "#0E7C86"; RED = "#C0392B"; GREY = "#7F8C8D"; GOLD = "#D4A017"

plt.rcParams.update({"font.family": "DejaVu Sans", "axes.edgecolor": "#CCCCCC",
                      "axes.spines.top": False, "axes.spines.right": False})

# 1. Category: sales vs margin
cats = [c["Category"] for c in R["by_category"]]
sales = [c["Sales"]/1e6 for c in R["by_category"]]
margin = [c["Margin %"] for c in R["by_category"]]
fig, ax1 = plt.subplots(figsize=(7, 4.2))
bars = ax1.bar(cats, sales, color=[TEAL, NAVY, GOLD], width=0.55)
ax1.set_ylabel("Sales ($M)")
ax2 = ax1.twinx()
ax2.plot(cats, margin, color=RED, marker="o", linewidth=2.5, markersize=9)
ax2.set_ylabel("Profit Margin %")
ax2.axhline(0, color="#999999", linewidth=0.8, linestyle="--")
for i, m in enumerate(margin):
    ax2.annotate(f"{m}%", (i, m), textcoords="offset points", xytext=(0, 10 if m>=0 else -18),
                 ha="center", fontsize=10, fontweight="bold", color=RED)
ax1.set_title("Sales vs. Profit Margin by Category", fontsize=13, fontweight="bold", color=NAVY, pad=14)
plt.tight_layout()
plt.savefig("/home/claude/project/chart_category.png", dpi=170)
plt.close()

# 2. Discount band margin
bands = [d["Discount Band"] for d in R["by_discount_band"]]
m2 = [d["Margin %"] for d in R["by_discount_band"]]
colors = [TEAL if x >= 0 else RED for x in m2]
fig, ax = plt.subplots(figsize=(7, 4.2))
bars = ax.bar(bands, m2, color=colors, width=0.55)
ax.axhline(0, color="#333333", linewidth=1)
for b, v in zip(bars, m2):
    ax.annotate(f"{v}%", (b.get_x()+b.get_width()/2, v), textcoords="offset points",
                xytext=(0, 6 if v>=0 else -16), ha="center", fontsize=10, fontweight="bold")
ax.set_ylabel("Profit Margin %")
ax.set_title("Profit Margin by Discount Band", fontsize=13, fontweight="bold", color=NAVY, pad=14)
plt.tight_layout()
plt.savefig("/home/claude/project/chart_discount.png", dpi=170)
plt.close()

# 3. Seasonality
months = [s["Order Month Name"][:3] for s in R["seasonality"]]
svals = [s["Sales"]/1e6 for s in R["seasonality"]]
fig, ax = plt.subplots(figsize=(8.5, 4.2))
colors3 = [GOLD if m == "Nov" else TEAL for m in months]
bars = ax.bar(months, svals, color=colors3, width=0.6)
ax.set_ylabel("Sales ($M)")
ax.set_title("Monthly Sales Seasonality (2011-2014 combined)", fontsize=13, fontweight="bold", color=NAVY, pad=14)
plt.tight_layout()
plt.savefig("/home/claude/project/chart_seasonality.png", dpi=170)
plt.close()

# 4. Tables loss deep dive
tb = R["tables_by_discount"]
tbands = [d["Discount Band"] for d in tb]
tprofit = [d["Profit"]/1000 for d in tb]
colors4 = [TEAL if x >= 0 else RED for x in tprofit]
fig, ax = plt.subplots(figsize=(7, 4.2))
bars = ax.bar(tbands, tprofit, color=colors4, width=0.55)
ax.axhline(0, color="#333333", linewidth=1)
for b, v in zip(bars, tprofit):
    ax.annotate(f"${v:,.0f}K", (b.get_x()+b.get_width()/2, v), textcoords="offset points",
                xytext=(0, 6 if v>=0 else -18), ha="center", fontsize=9, fontweight="bold")
ax.set_ylabel("Profit ($K)")
ax.set_title("Tables Sub-Category: Profit by Discount Band", fontsize=13, fontweight="bold", color=NAVY, pad=14)
plt.tight_layout()
plt.savefig("/home/claude/project/chart_tables.png", dpi=170)
plt.close()

# 5. Top cities
tc = R["top_cities"][:8]
names = [c["City"] for c in tc][::-1]
vals = [c["Sales"]/1e6 for c in tc][::-1]
fig, ax = plt.subplots(figsize=(7, 4.5))
ax.barh(names, vals, color=NAVY, height=0.55)
ax.set_xlabel("Sales ($M)")
ax.set_title("Top 8 Cities by Sales", fontsize=13, fontweight="bold", color=NAVY, pad=14)
plt.tight_layout()
plt.savefig("/home/claude/project/chart_cities.png", dpi=170)
plt.close()

# 6. Market share
mk = R["by_market"]
labels = [m["Market"] for m in mk]
vals = [m["Sales"] for m in mk]
fig, ax = plt.subplots(figsize=(6, 5))
colors5 = [NAVY, TEAL, GOLD, GREY, RED]
wedges, texts, autotexts = ax.pie(vals, labels=labels, autopct="%1.0f%%", colors=colors5,
                                   startangle=90, pctdistance=0.75,
                                   wedgeprops=dict(width=0.42, edgecolor="white"))
ax.set_title("Sales Share by Market", fontsize=13, fontweight="bold", color=NAVY, pad=14)
plt.tight_layout()
plt.savefig("/home/claude/project/chart_market.png", dpi=170)
plt.close()

print("Charts saved.")
