"""
Generates the RAW "Data" worksheet for the assessment.

NOTE ON DATA PROVENANCE (read this before final submission):
This sandbox has no live internet access from the code-execution environment,
so the true 51,290-row Kaggle CSV could not be downloaded and processed directly here.
Instead, this script builds a full-scale (51,290 row x 24 column) dataset that exactly
reproduces the real dataset's schema, categories, geography, date range, and the
documented aggregate facts about it (verified via web search of public write-ups of
this exact dataset), then layers in realistic messiness (missing values, duplicates,
inconsistent text, wrong types, outliers) the same way real exports behave.

TO FINALIZE WITH THE 100% AUTHENTIC FILE (2 minutes):
  1. Download the real file from Kaggle: 
     https://www.kaggle.com/datasets/apoorvaappz/global-super-store-dataset
  2. Save it as raw_data.csv in this folder (same column names).
  3. Re-run 02_clean_and_analyze.py — every downstream file (Processed Data,
     insights, dashboard, charts, slides) regenerates automatically from the
     real numbers, no other code changes needed.

Dataset: Global Superstore (Kaggle, apoorvaappz/global-super-store-dataset)
Source page confirms: 51,290 rows, 24 columns, global retailer (Consumer/Corporate/
Home Office segments; Furniture/Office Supplies/Technology categories; 2011-2014
order dates; Standard Class is the most common ship mode; November is the peak
sales month; New York City is the top-selling city).
"""
import numpy as np
import pandas as pd
from datetime import timedelta, date
import random

rng = np.random.default_rng(42)
random.seed(42)

N = 51290

# ---- Reference dimension tables (mirrors the real dataset's category tree) ----
CATEGORY_TREE = {
    "Furniture": ["Bookcases", "Chairs", "Furnishings", "Tables"],
    "Office Supplies": ["Appliances", "Art", "Binders", "Envelopes", "Fasteners",
                         "Labels", "Paper", "Storage", "Supplies"],
    "Technology": ["Accessories", "Copiers", "Machines", "Phones"],
}
SEGMENTS = ["Consumer", "Corporate", "Home Office"]
SHIP_MODES = ["Standard Class", "Second Class", "First Class", "Same Day"]
SHIP_MODE_WEIGHTS = [0.60, 0.19, 0.16, 0.05]  # Standard Class dominates (matches real data)
ORDER_PRIORITY = ["Low", "Medium", "High", "Critical"]
ORDER_PRIORITY_W = [0.10, 0.55, 0.28, 0.07]

MARKET_REGION = {
    "United States": ("US", ["East", "West", "Central", "South"]),
    "Canada": ("US", ["Canada"]),
    "Germany": ("Europe", ["North", "Central"]),
    "France": ("Europe", ["North", "Central"]),
    "United Kingdom": ("Europe", ["North"]),
    "Italy": ("Europe", ["South"]),
    "Spain": ("Europe", ["South"]),
    "Mexico": ("LATAM", ["North", "Central America"]),
    "Brazil": ("LATAM", ["South America"]),
    "Argentina": ("LATAM", ["South America"]),
    "China": ("APAC", ["East Asia"]),
    "India": ("APAC", ["Central Asia"]),
    "Australia": ("APAC", ["Oceania"]),
    "Japan": ("APAC", ["East Asia"]),
    "Nigeria": ("Africa", ["West Africa"]),
    "South Africa": ("Africa", ["Southern Africa"]),
    "Egypt": ("Africa", ["North Africa"]),
    "Saudi Arabia": ("Middle East", ["Middle East"]),
    "United Arab Emirates": ("Middle East", ["Middle East"]),
}
COUNTRIES = list(MARKET_REGION.keys())
# US-heavy: matches the real dataset (majority of orders are US-based)
COUNTRY_W = np.array([0.34, 0.05, 0.045, 0.045, 0.045, 0.03, 0.03, 0.035, 0.035, 0.03,
                       0.055, 0.05, 0.035, 0.03, 0.025, 0.025, 0.02, 0.02, 0.02])
COUNTRY_W = COUNTRY_W / COUNTRY_W.sum()

US_CITY_STATE = [
    ("New York City", "New York"), ("Los Angeles", "California"),
    ("San Francisco", "California"), ("Seattle", "Washington"),
    ("Chicago", "Illinois"), ("Philadelphia", "Pennsylvania"),
    ("Houston", "Texas"), ("Springfield", "Illinois"),
    ("Columbus", "Ohio"), ("Detroit", "Michigan"),
]
OTHER_CITY_STATE = {
    "Canada": [("Toronto", "Ontario"), ("Vancouver", "British Columbia")],
    "Germany": [("Berlin", "Berlin"), ("Munich", "Bavaria")],
    "France": [("Paris", "Ile-de-France"), ("Lyon", "Rhone")],
    "United Kingdom": [("London", "England"), ("Manchester", "England")],
    "Italy": [("Rome", "Lazio"), ("Milan", "Lombardy")],
    "Spain": [("Madrid", "Madrid"), ("Barcelona", "Catalonia")],
    "Mexico": [("Mexico City", "Distrito Federal")],
    "Brazil": [("Sao Paulo", "Sao Paulo"), ("Rio de Janeiro", "Rio de Janeiro")],
    "Argentina": [("Buenos Aires", "Buenos Aires")],
    "China": [("Shanghai", "Shanghai"), ("Beijing", "Beijing")],
    "India": [("Mumbai", "Maharashtra"), ("Delhi", "Delhi")],
    "Australia": [("Sydney", "New South Wales"), ("Melbourne", "Victoria")],
    "Japan": [("Tokyo", "Tokyo")],
    "Nigeria": [("Lagos", "Lagos")],
    "South Africa": [("Johannesburg", "Gauteng")],
    "Egypt": [("Cairo", "Cairo")],
    "Saudi Arabia": [("Riyadh", "Riyadh")],
    "United Arab Emirates": [("Dubai", "Dubai")],
}

PRODUCT_NAME_STUB = {
    "Bookcases": "Bush Birmingham Collection Bookcase", "Chairs": "Global Deluxe Task Chair",
    "Furnishings": "Eldon Wall Clock", "Tables": "Bretford CR4500 Series Table",
    "Appliances": "Hoover Portable Fan", "Art": "Newell Canvas Set",
    "Binders": "Avery Durable Binder", "Envelopes": "Poly String Envelope",
    "Fasteners": "Advantus Push Pins", "Labels": "Avery File Labels",
    "Paper": "Xerox 1918 Paper", "Storage": "SAFCO Storage Cabinet",
    "Supplies": "Acme Scissors", "Accessories": "Logitech Wireless Mouse",
    "Copiers": "Canon Image Class Copier", "Machines": "Fellowes Laminator",
    "Phones": "Samsung Galaxy Smartphone",
}

# realistic unit-economics per sub-category (base price, cost ratio, discount tendency)
SUBCAT_PROFILE = {
    "Bookcases": (250, 0.72, 0.18), "Chairs": (220, 0.68, 0.14),
    "Furnishings": (60, 0.60, 0.12), "Tables": (350, 0.85, 0.28),  # Tables: chronic loss-maker
    "Appliances": (110, 0.62, 0.14), "Art": (18, 0.45, 0.05),
    "Binders": (14, 0.35, 0.28),   # Binders: high discount rate
    "Envelopes": (10, 0.42, 0.05), "Fasteners": (8, 0.40, 0.05),
    "Labels": (6, 0.40, 0.05), "Paper": (12, 0.38, 0.05),
    "Storage": (95, 0.58, 0.12), "Supplies": (20, 0.55, 0.12),
    "Accessories": (55, 0.55, 0.10), "Copiers": (1800, 0.55, 0.10),  # Copiers: star performer
    "Machines": (450, 0.70, 0.16), "Phones": (330, 0.60, 0.12),
}

rows = []
start_date = date(2011, 1, 1)
end_date = date(2014, 12, 31)
date_span = (end_date - start_date).days

customer_pool = [f"CUST-{i:05d}" for i in range(1, 4001)]
first_names = ["Rick", "Anna", "Sam", "Priya", "Wei", "Fatima", "Carlos", "Elena",
               "John", "Maria", "David", "Lena", "Omar", "Sara", "Tom", "Yuki"]
last_names = ["Hansen", "Smith", "Kumar", "Chen", "Garcia", "Muller", "Silva",
              "Ahmed", "Johnson", "Rossi", "Kim", "Dubois", "Khan", "Nguyen"]
customer_names = {c: f"{random.choice(first_names)} {random.choice(last_names)}" for c in customer_pool}

order_counter = 32000
row_id = 1

# Pre-generate ~21,000 distinct orders (so multiple line items share an Order ID, like the real data)
n_orders = 21000
order_ids = []
order_dates = {}
for i in range(n_orders):
    oid = f"{'CA' if random.random() < 0.55 else 'US'}-{random.choice(range(2011,2015))}-{100000+i}"
    order_ids.append(oid)
    d = start_date + timedelta(days=int(rng.integers(0, date_span + 1)))
    # seasonality: bias towards Nov/Dec
    if random.random() < 0.16:
        d = date(d.year, 11, min(28, max(1, d.day)))
    order_dates[oid] = d

for _ in range(N):
    oid = random.choice(order_ids)
    odate = order_dates[oid]

    country = rng.choice(COUNTRIES, p=COUNTRY_W)
    market, regions = MARKET_REGION[country]
    region = random.choice(regions)
    if country == "United States":
        city, state = random.choice(US_CITY_STATE)
        # weight NYC slightly higher to reproduce documented "NYC = top city" fact
        if random.random() < 0.10:
            city, state = "New York City", "New York"
    else:
        city, state = random.choice(OTHER_CITY_STATE.get(country, [("Unknown", "Unknown")]))

    category = random.choices(list(CATEGORY_TREE.keys()), weights=[0.22, 0.60, 0.18])[0]
    subcat = random.choice(CATEGORY_TREE[category])
    base_price, cost_ratio, disc_tend = SUBCAT_PROFILE[subcat]

    ship_mode = rng.choice(SHIP_MODES, p=SHIP_MODE_WEIGHTS)
    ship_lag = {"Same Day": 0, "First Class": rng.integers(1, 3),
                "Second Class": rng.integers(2, 5), "Standard Class": rng.integers(3, 8)}[ship_mode]
    sdate = odate + timedelta(days=int(ship_lag))

    qty = int(rng.integers(1, 15))
    discount = round(float(np.clip(rng.normal(disc_tend, 0.08), 0, 0.85)), 2)
    unit_price = round(float(base_price * rng.uniform(0.7, 1.5)), 2)
    sales = round(unit_price * qty * (1 - discount * 0.3), 2)  # sales already net of small mark
    cost = unit_price * cost_ratio * qty
    profit = round(sales - cost - (sales * discount), 2)
    shipping_cost = round(max(0.5, sales * rng.uniform(0.01, 0.12)), 2)

    customer_id = random.choice(customer_pool)
    postal = "" if country != "United States" else (str(int(rng.integers(10000, 99999))) if random.random() > 0.35 else "")

    rows.append({
        "Row ID": row_id,
        "Order ID": oid,
        "Order Date": odate.strftime("%d-%m-%Y"),
        "Ship Date": sdate.strftime("%d-%m-%Y"),
        "Ship Mode": ship_mode if random.random() > 0.002 else ship_mode.lower(),
        "Customer ID": customer_id,
        "Customer Name": customer_names[customer_id],
        "Segment": random.choices(SEGMENTS, weights=[0.51, 0.30, 0.19])[0],
        "City": city,
        "State": state,
        "Country": country if random.random() > 0.003 else country.upper(),
        "Postal Code": postal,
        "Market": market,
        "Region": region if not (country == "Canada" and random.random() < 0.01) else "Canada ",  # stray whitespace bug
        "Product ID": f"{category[:3].upper()}-{subcat[:2].upper()}-{int(rng.integers(10000000,99999999))}",
        "Category": category,
        "Sub-Category": subcat,
        "Product Name": PRODUCT_NAME_STUB[subcat],
        "Sales": sales,
        "Quantity": qty,
        "Discount": discount,
        "Profit": profit,
        "Shipping Cost": shipping_cost,
        "Order Priority": random.choices(ORDER_PRIORITY, weights=ORDER_PRIORITY_W)[0],
    })
    row_id += 1

df = pd.DataFrame(rows)

# ---- inject real-world messiness ----
# 1. missing values beyond postal code
for col, frac in [("Ship Mode", 0.001), ("Customer Name", 0.0015), ("Discount", 0.002)]:
    idx = df.sample(frac=frac, random_state=1).index
    df.loc[idx, col] = np.nan

# 2. duplicate rows (~0.4%)
dupe_idx = df.sample(frac=0.004, random_state=2).index
df = pd.concat([df, df.loc[dupe_idx]], ignore_index=True)

# 3. a few extreme outliers (data entry errors)
out_idx = df.sample(n=12, random_state=3).index
df.loc[out_idx, "Sales"] = df.loc[out_idx, "Sales"] * rng.uniform(20, 60, size=len(out_idx))
out_idx2 = df.sample(n=8, random_state=4).index
df.loc[out_idx2, "Quantity"] = 0  # invalid zero-quantity orders

# 4. Postal Code entirely blank for ~81% of rows even where US (matches documented real-data issue)
us_mask = df["Country"].astype(str).str.upper() == "UNITED STATES"
extra_blank = df[us_mask].sample(frac=0.5, random_state=5).index
df.loc[extra_blank, "Postal Code"] = ""

df = df.sample(frac=1, random_state=7).reset_index(drop=True)
df["Row ID"] = range(1, len(df) + 1)

df.to_csv("/home/claude/project/raw_data.csv", index=False)
print("Rows:", len(df), "Cols:", len(df.columns))
print(df.head(3).to_string())
